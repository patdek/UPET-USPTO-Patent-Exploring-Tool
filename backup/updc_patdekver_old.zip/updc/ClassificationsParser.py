import os

class ClassificationParser(object):
    """
    Used to parse Classification data and insert them into the database.
    processing data:"U.S. Manual of Classification File (CTAF, Classification Text Attribute File)/ctaf1204.txt"
    """

    def __init__(self):
        self.cls=''
        self.subcls=''
        self.indent=''
        self.subclsSeqNum=''
        self.nextHigSub=''
        self.title=''
        self.clsList=[]

    def GetClasses(self,filePath):
        reader=open(filePath,'r')
        readerList=reader.readlines()
        for line in readerList:
            self.cls=line[0:3]
            self.subcls=line[3:9]
            self.indent=line[9:11]
            self.subclsSeqNum=line[11:15]
            self.nextHigSub=line[15:21]
            self.title=line[21:len(line)+1].strip()[0:140]
            self.clsList.append([self.cls,self.subcls,self.indent,self.subclsSeqNum,self.nextHigSub,self.title])
        reader.close()
        return self.clsList

if __name__=="__main__":
    parser=ClassificationParser()
    filePath=os.getcwd()+"/CLS/ctaf1204.txt"
    lst=parser.GetClasses(filePath)
    import MySQLProcessor
    processor=MySQLProcessor.MySQLProcess()
    processor.connect()
    print len(lst)
    for i in range(0,17):
        if((i+1)*10000<len(lst)):
            processor.executeMany("INSERT INTO qliu14.USCLASSIFICATION (Class,Subclass,Indent,SubclsSqsNum,NextHigherSub,Title) VALUES (%s,%s,%s,%s,%s,%s)",lst[i*10000:(i+1)*10000])
        else:
            processor.executeMany("INSERT INTO qliu14.USCLASSIFICATION (Class,Subclass,Indent,SubclsSqsNum,NextHigherSub,Title) VALUES (%s,%s,%s,%s,%s,%s)",lst[i*10000:len(lst)+1])
        print '{0}*10000 records have been inserted into the table [USCLASSIFICATION] successfully!'.format(i+1)
    processor.close()
    print '**********\nCongratulations!{0} records have been inserted into the database successfully!\n**********'.format(len(lst))
    text=raw_input('Press ENTER to continue')


