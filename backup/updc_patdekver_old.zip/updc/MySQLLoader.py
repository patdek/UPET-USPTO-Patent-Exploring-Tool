import MySQLProcessor
import os
import re

class LoadCSV:
    """
    Used to load .csv files into the MySQL database
    1.download all the .csv files of Grants/Publications/PAIR
    2.make sure the following folder names are correct 'CSV_P,CSV_G,CSV_PAIR'
    3.run MySQLLoader.py
    """
    def __init__(self):
        self.csvDir_P=os.getcwd().replace('\\','/')+'/CSV_P/'
        self.csvDir_G=os.getcwd().replace('\\','/')+'/CSV_G/'
        self.csvDir_PAIR=os.getcwd().replace('\\','/')+'/CSV_PAIR/'

    def loadGrants(self,tableName):
        self.processor=MySQLProcessor.MySQLProcess()
        self.processor.connect()
        self.processor.load('SET foreign_key_checks = 0;')
        for fileName in os.listdir(self.csvDir_G):
            if(re.search(tableName.split('_')[0],fileName,flags=re.IGNORECASE)):
                print 'Populating '+fileName+' into the database.'
                print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
                IGNORE INTO TABLE qliu14.{tableName}        FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
                """.format(filePath=self.csvDir_G+fileName,tableName=tableName))
        self.processor.load('SET foreign_key_checks = 1;')
        self.processor.close()

    def loadPublications(self,tableName):
        self.processor=MySQLProcessor.MySQLProcess()
        self.processor.connect()
        self.processor.load('SET foreign_key_checks = 0;')
        for fileName in os.listdir(self.csvDir_P):
            if(re.search(tableName.split('_')[0],fileName,flags=re.IGNORECASE)):
                print 'Populating '+fileName+' into the database.'
                print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
                IGNORE INTO TABLE qliu14.{tableName}        FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
                """.format(filePath=self.csvDir_P+fileName,tableName=tableName))
        self.processor.load('SET foreign_key_checks = 1;')
        self.processor.close()

    def loadPAIR(self,tableName):
        self.processor=MySQLProcessor.MySQLProcess()
        self.processor.connect()
        self.processor.load('SET foreign_key_checks = 0;')
        for fileName in os.listdir(self.csvDir_PAIR):
            if(re.search(tableName[0],fileName,flags=re.IGNORECASE)):
                print 'Populating '+fileName+' into the database.'
                print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
                IGNORE INTO TABLE qliu14.{tableName}        FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
                """.format(filePath=self.csvDir_PAIR+fileName,tableName=tableName))
        self.processor.load('SET foreign_key_checks = 1;')
        self.processor.close()

if __name__=="__main__":
    import time
    st=time.time()
    loader=LoadCSV()
    loader.loadGrants('APPLICATION')
    loader.loadGrants('GRANT')
    loader.loadGrants('AGENT_G')
    loader.loadGrants('EXAMINER_G')
    loader.loadGrants('ASSIGNEE_G')
    loader.loadGrants('INVENTOR_G')
    loader.loadGrants('INTCLASS_G')
    loader.loadGrants('PUBCIT_G')
    loader.loadGrants('GRACIT_G')
    loader.loadGrants('FORPATCIT_G')
    loader.loadGrants('NONPATCIT_G')
    loader.loadGrants('USCLASS_G')

    loader.loadPublications('APPLICATION')
    loader.loadPublications('PUBLICATION')
    loader.loadPublications('AGENT_P')
    loader.loadPublications('EXAMINER_P')
    loader.loadPublications('ASSIGNEE_P')
    loader.loadPublications('INVENTOR_P')
    loader.loadPublications('INTCLASS_P')
    loader.loadPublications('PUBCIT_P')
    loader.loadPublications('GRACIT_P')
    loader.loadPublications('FORPATCIT_P')
    loader.loadPublications('NONPATCIT_P')
    loader.loadPublications('USCLASS_P')

    print 'ALL .csv files have been loaded into the database. Time:{time}'.format(time=time.time()-st)
