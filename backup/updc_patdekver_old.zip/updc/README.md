# Info
So, this project is from: 

# Get it working
Needs python 2.6 and various things to actually work, 

sudo add-apt-repository ppa:fkrull/deadsnakes
sudo apt-get install libmysqlclient-dev
sudo apt-get install python2.6-dev

# Needs these directories 
CLS
CSV_G
CSV_LOG
CSV_P
CSV_PAIR
ID
LOG
PAIR
PG_BD
PP_BD
