import LogProcessor
import SourceParser
import os
import GrantsParser
import PublicationsParser
import PAIRParserSeg

class AutoUpdate(object):
    """
    Used for automatic updating in a specific period of time.(Weekly)
    1.check log file to obtain processed files list
    2.check web to obtain all processable files list
    3.get unprocessed files list and ask user to continue or exit
    """
    def __init__(self):
        self.logPath_P=os.getcwd().replace('\\','/')+'/LOG/LOG_P'
        self.logPath_G=os.getcwd().replace('\\','/')+'/LOG/LOG_G'
        self.logPath_PAIR=os.getcwd().replace('\\','/')+'/LOG/LOG_PAIR'
        self.urlLinkName_PAIR='http://commondatastorage.googleapis.com/uspto-pair/applications/[replaceNum].zip'

        self.allG=[]
        self.allP=[]
        self.allPAIR=[]

        self.processedG=[]
        self.processedP=[]
        self.processedPAIR=[]

        self.sprocessedG=[]
        self.sprocessedP=[]
        self.sprocessedPAIR=[]
        
        self.unprocessedG=[]
        self.unprocessedP=[]
        self.unprocessedPAIR=[]

    def __checkAll(self):
        log=LogProcessor.LogProcess()
        f_log_g=open(self.logPath_G,'rb')
        f_log_p=open(self.logPath_P,'rb')
        f_log_pair=open(self.logPath_PAIR,'rb')
        self.processedG=f_log_g.readlines()
        self.processedP=f_log_p.readlines()
        self.processedPAIR=f_log_pair.readlines()
        for i in self.processedG:
            if(i.split('\t')[4].strip()=='Processed' or i.split('\t')[4].strip()=='Passed'):self.sprocessedG.append(i.split('\t')[2])
        for i in self.processedP:
            if(i.split('\t')[4].strip()=='Processed'):self.sprocessedP.append(i.split('\t')[2])
        for i in self.processedPAIR:
            if(i.split('\t')[4].strip()=='Processed'):self.sprocessedPAIR.append(i.split('\t')[2])
        sp=SourceParser.SourceParser()
        self.allG=sp.getdLinksPG()
        self.allP=sp.getdLinksPP()
        self.allPAIR=sp.getdLinksPAIR()
        self.unprocessedG=list(set(self.allG)-set(self.sprocessedG))
        self.unprocessedP=list(set(self.allP)-set(self.sprocessedP))
        self.unprocessedPAIR=list(set(self.allPAIR)-set(self.sprocessedPAIR))

if __name__=="__main__":
    print '*'*21
    print 'Check for updates now...'
    print '*'*21
    auto=AutoUpdate()
    auto._AutoUpdate__checkAll()
    print '='*21+' Data Statistics '+'='*21
    print '          \tGRA \tPUB \tPAIR'
    print 'CurrentAll\t'+str(len(auto.allG))+'\t'+str(len(auto.allP))+'\t'+str(len(auto.allPAIR))
    print 'Processed \t'+str(len(auto.processedG))+'\t'+str(len(auto.processedP))+'\t'+str(len(auto.processedPAIR))
    print 'SProcessed\t'+str(len(auto.sprocessedG))+'\t'+str(len(auto.sprocessedP))+'\t'+str(len(auto.sprocessedPAIR))
    print 'UProcessed\t'+str(len(auto.unprocessedG))+'\t'+str(len(auto.unprocessedP))+'\t'+str(len(auto.unprocessedPAIR))
    print '='*21+' Grants Updates '+'='*21
    if(len(auto.unprocessedG)>0):
        text=raw_input('Grants:{0} files to be updated!\nPress \'Y/y\' to continue.'.format(len(auto.unprocessedG)))
        if(text.upper()=='Y'):
            GrantsParser.mainProcess(auto.unprocessedG,'xml4')
        else:
            pass
    print '='*21+' Publications Updates '+'='*21
    if(len(auto.unprocessedP)>0):
        text=raw_input('Publciatoins:{0} files to be updated!\nPress \'Y/y\' to continue.'.format(len(auto.unprocessedP)))
        if(text.upper()=='Y'):
            PublicationsParser.mainProcess(auto.unprocessedP,'xml4')
        else:
            pass
    print '='*21+' PAIR Data Updates '+'='*21
    if(len(auto.unprocessedPAIR)>0):
        text=raw_input('PAIR Data:{0} files to be updated!\nPress \'Y/y\' to continue.'.format(len(auto.unprocessedPAIR)))
        if(text.upper()=='Y'):
            PAIRParserSeg.multiProcess(auto.unprocessedPAIR,1000)
        else:
            pass
    raw_input('All updates have been processed successfully!')


