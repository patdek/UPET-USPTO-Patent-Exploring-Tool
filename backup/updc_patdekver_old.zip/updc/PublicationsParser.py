import xml.etree.ElementTree as ET
import time
import MySQLProcessor
import re
import SourceParser
import os
import multiprocessing
import LogProcessor

class PublicationsParser():
    """
    Used to parse Patent Applicaiton Publications data and populate them into the database.
    1. obtain contents from SourceParser.py
    2. parse the content and generate .csv files
    3. load .csv files into the database.
    """
    def __init__(self):
        self.pubCountry=''
        self.pubNo=''
        self.kind=''
        self.pubDate=''
        self.appCountry=''
        self.appNo=''
        self.appDate=''
        self.appType=''
        self.seriesCode=''

        # priority claims
        self.pcSequence=''
        self.pcKind=''
        self.pcCountry=''
        self.pcDocNum=''
        self.pcDate=''
        self.priClaim=[]
        self.priClaimsList=[]

        # international classification
        self.iClassVersionDate=''
        self.iClassLevel=''
        self.iClassSec='' #section
        self.iClassCls='' #mainclass
        self.iClassSub='' #subclass
        self.iClassMgr='' #main group
        self.iClassSgr='' #subgroup 
        self.iClassSps='' #symbol position
        self.iClassVal='' # classification value
        self.iClassActionDate=''
        self.iClassGnr=''  # generating office
        self.iClassStatus='' #status
        self.iClassDS=''  #data source
        self.iClassList=[]

        #national classification
        self.nClassCountry=''
        self.nClassMain=''
        self.nSubclass=''
        self.nClassInfo=''   #mainClass=nClassInfo[0:3] subClass=nClassInfo[3:len(nClassInfo)]
        self.nClassList=[]

        self.title=''

        # citations 
        self.ctNum=''
        self.pctCountry=''  # pct : patent citation
        self.pctDocNo=''
        self.pctKind=''
        self.pctName=''
        self.pctDate=''
        self.pctCategory=''
        self.pctClassNation=''
        self.pctClassMain=''
        self.pctClassList=[]
        self.pcitation=[]
        self.pcitationsList=[]  # list of pcitation
        self.pcitationsList_US=[]
        self.pcitationsList_FC=[]

        self.npctDoc=''
        self.npctCategory=''
        self.npcitation=[]
        self.npcitationsList=[] # list of npcitation

        self.claimsNum=''
        self.figuresNum=''
        self.drawingsNum=''

        # ommit us-related-documents

        # inventors info. 
        self.itSequence=''
        self.itFirstName=''  #it inventor
        self.itLastName=''
        self.itCity=''
        self.itState=''
        self.itCountry=''
        self.itNationality=''
        self.itResidence=''
        self.inventor=[]
        self.inventorsList=[]

        # attorney
        # attorney maybe organizations or, one or more than one person
        self.atnSequence=''
        self.atnLastName=''
        self.atnFirstName=''
        self.atnOrgName=''   
        self.atnCountry=''
        self.attorney=[]
        self.attorneyList=[]
    
        #assignee
        self.asnSequence=''
        self.asnOrgName=''
        self.asnRole=''
        self.asnCity=''
        self.asnState=''
        self.asnCountry=''
        self.assignee=[]
        self.assigneeList=[]

        #examiners
        #primary-examiner & assistant-examiner
        self.exmLastName=''
        self.exmFirstName=''
        self.exmDepartment=''
        self.examiner=[]
        self.examinerList=[]

        self.abstract=''
        self.claims=''
        self.test=''  #used for testing

        self.position=1
        self.count=1
        self.csvPath_application=os.getcwd()+'/CSV_P/application_'
        self.csvPath_publication=os.getcwd()+'/CSV_P/publication_'
        self.csvPath_agent=os.getcwd()+'/CSV_P/agent_'
        self.csvPath_assignee=os.getcwd()+'/CSV_P/assignee_'
        self.csvPath_examiner=os.getcwd()+'/CSV_P/examiner_'
        self.csvPath_intclass=os.getcwd()+'/CSV_P/intclass_'
        self.csvPath_inventor=os.getcwd()+'/CSV_P/inventor_'
        self.csvPath_pubcit=os.getcwd()+'/CSV_P/pubcit_'
        self.csvPath_gracit=os.getcwd()+'/CSV_P/gracit_'
        self.csvPath_forpatcit=os.getcwd()+'/CSV_P/forpatcit_'
        self.csvPath_nonpatcit=os.getcwd()+'/CSV_P/nonpatcit_'
        self.csvPath_usclass=os.getcwd()+'/CSV_P/usclass_'

    def __ResetSQLVariables(self):
        # ***************** SQL ***************************
        self.sql_application=[] #application
        self.sql_publication=[] #publications
        self.sql_grant=[] #grants

        self.sql_examiner=[]
        self.sql_assignee=[]
        self.sql_agent=[]
        self.sql_inventor=[]
        self.sql_usclass=[]
        self.sql_intclass=[]
        self.sql_pubcit=[]  #publication citations
        self.sql_gracit=[] #grant citations
        self.sql_forpatcit=[] #foreign patent citations
        self.sql_nonpatcit=[] #none-patent citations

    def __checkTag(self,x,tagName=''):
        if(x.tag==tagName):
            return True
        else:
            return False

    def __returnClass(self,s='D 2860'):
        """
        Main Class (3):'D02','PLT','000'
        SubClass (3.3): 
        """
        mc=s[0:3].replace(' ','')
        sc=s[3:len(s)]
        sc1=sc[0:3].replace(' ','0')
        sc2=sc[3:len(sc)].replace(' ','')
        if(len(mc)<=3):
            if(mc.find('D')>-1 and len(mc)==2):mc=mc[0]+'0'+mc[1]
            elif(len(mc)==2):mc='0'+mc
            elif(len(mc)==1):mc='00'+mc
        if(len(sc2)<=3):
            if(len(sc2)==2):sc2='0'+sc2
            elif(len(sc2)==1):sc2='00'+sc2
            elif(len(sc2)==0):sc2='000'
        clist=[mc,sc1+sc2]
        return clist

    def __returnDate(self,timeStr):
        if(len(timeStr)>7):
            return timeStr[0:4]+'-'+timeStr[4:6]+'-'+timeStr[6:8]
        else:
            return None

    def __returnInt(self,s):
        try:
            if(s=='' or s==None):return 'NULL';
            else:return int(s)
        except:return 'NULL'

    def __returnStr(self,s):
        try:
            if(s=='' or s==None):return '';
            else:return s.encode('utf-8').replace('"','\'').strip()
        except:return ''

    def extractXML4(self,xmlStr):      
        print '- Starting read .xml'
        self.__ResetSQLVariables()
        btime=time.time()
        patentRoot=ET.fromstring(xmlStr)
        #patentRoot=ET.ElementTree().parse('D:\PatentsData\PG_BD\haha.xml')
        print '[Finished read xml. Time:{0}]'.format(time.time()-btime)
        print '- Starting extract .xml'
        btime=time.time()
        # regular info.
        for root in patentRoot.findall('us-patent-application'):
            self.__init__()
            for r in root.findall('us-bibliographic-data-application'):
                for pr in r.findall('publication-reference'):
                    for di in pr.findall('document-id'):
                        self.pubCountry=di.findtext('country')
                        self.pubNo=di.findtext('doc-number')
                        self.kind=di.findtext('kind')
                        self.pubDate=di.findtext('date')
                for ar in r.getiterator('application-reference'):
                    self.appType=ar.attrib['appl-type']
                    for di in ar.findall('document-id'):
                        self.appCountry=di.findtext('country')
                        self.appNo=di.findtext('doc-number')
                        self.appDate=di.findtext('date')
                self.seriesCode=r.findtext('us-application-series-code')
                #for pc in r.findall('priority-claims'):
                #    for pcs in pc.getiterator('priority-claim'):
                #        self.pcSequence=pcs.attrib['sequence']
                #        self.pcKind=pcs.attrib['kind']
                #        self.pcCountry=pcs.findtext('country')
                #        self.pcDocNum=pcs.findtext('doc-number')
                #        self.pcDate=pcs.findtext('date')
                #        self.priClaim=[self.pcSequence,self.pcKind,self.pcCountry,self.pcDocNum,self.pcDate]
                #        self.priClaimsList.append(self.priClaim)
                for ic in r.findall('classifications-ipcr'):
                    self.position=1
                    for icc in ic.findall('classification-ipcr'):
                        for ivi in icc.findall('ipc-version-indicator'):
                            self.iClassVersionDate=ivi.findtext('date')
                        for ad in icc.getiterator('action-date'):
                            self.iClassActionDate=ad.findtext('date')
                        for go in icc.findall('generating-office'):
                            self.iClassGnr=go.findtext('country')
                        for x in icc.getchildren():
                            if(self.__checkTag(x,'classification-level')):self.iClassLevel=x.text
                            if(self.__checkTag(x,'section')):self.iClassSec=x.text
                            if(self.__checkTag(x,'class')):self.iClassCls=x.text
                            if(self.__checkTag(x,'subclass')):self.iClassSub=x.text
                            if(self.__checkTag(x,'main-group')):self.iClassMgr=x.text
                            if(self.__checkTag(x,'subgroup')):self.iClassSgr=x.text
                            if(self.__checkTag(x,'symbol-position')): self.iClassSps=x.text
                            if(self.__checkTag(x,'classification-value')):self.iClassVal=x.text
                            if(self.__checkTag(x,'classfication-status')):self.iClassStatus=x.text
                            if(self.__checkTag(x,'classification-date-source')):self.iClassDS=x.text
                        #self.iClassList.append([self.pubNo,self.position,self.iClassSec,self.iClassCls,self.iClassSub,self.iClassMgr,self.iClassSgr])
                        self.sql_intclass.append([self.pubNo,self.position,self.iClassSec,self.iClassCls,self.iClassSub,self.iClassMgr,self.iClassSgr])
                        self.position+=1
                for nc in r.findall('classification-national'):
                    self.position=1
                    self.nClassCountry=nc.findtext('country')
                    self.nClassInfo=nc.findtext('main-classification')
                    self.nClassMain=self.__returnClass(self.nClassInfo)[0]
                    self.nSubclass=self.__returnClass(self.nClassInfo)[1]
                    self.sql_usclass.append([self.pubNo,self.position,self.__returnStr(self.nClassMain),self.__returnStr(self.nSubclass)])
                    nClassFurRoot=nc.findall('further-classification') #return a list of all elements
                    for n in nClassFurRoot: #return a list of all subelements
                        self.position+=1
                        self.nClassInfo=n.text
                        self.nClassMain=self.__returnClass(self.nClassInfo)[0]
                        self.nSubclass=self.__returnClass(self.nClassInfo)[1]
                        self.sql_usclass.append([self.pubNo,self.position,self.__returnStr(self.nClassMain),self.__returnStr(self.nSubclass)])                        
                try:
                    self.title=r.findtext('invention-title')
                except:
                    self.title='TITLE ERROR'
                    print '******************************************************************** Title Error **********************************'
                    continue
                for rf in r.findall('references-cited'):
                    for rfc in rf.findall('citation'):
                        if(rfc.find('patcit')!=None):
                            self.ctNum=rfc.find('patcit').attrib['num']
                            for x in rfc.findall('patcit'):
                                self.pctCountry=x.find('document-id').findtext('country')
                                self.pctDocNo=x.find('document-id').findtext('doc-number')
                                self.pctKind=x.find('document-id').findtext('kind')
                                self.pctName=x.find('document-id').findtext('name')
                                self.pctDate=x.find('document-id').findtext('date')
                            self.pctCategory=rfc.findtext('category')
                            #us patent citations
                            if(self.pctCountry.strip().upper()=='US'):
                                if(self.pctDocNo.find('/')>-1):
                                    self.sql_pubcit.append([self.pubNo,self.ctNum,self.pctDocNo,self.pctKind,self.__returnStr(self.pctName),self.__returnDate(self.pctDate),self.pctCountry,self.__returnStr(self.pctCategory)])
                                else:
                                    self.sql_gracit.append([self.pubNo,self.ctNum,self.pctDocNo,self.pctKind,self.__returnStr(self.pctName),self.__returnDate(self.pctDate),self.pctCountry,self.__returnStr(self.pctCategory)])
                            elif(self.pctCountry.strip().upper()!='US'):
                                self.sql_forpatcit.append([self.pubNo,self.ctNum,self.pctDocNo,self.pctKind,self.__returnStr(self.pctName),self.__returnDate(self.pctDate),self.pctCountry,self.__returnStr(self.pctCategory)])
                        elif(rfc.find('nplcit')!=None):
                            self.ctNum=rfc.find('nplcit').attrib['num']
                            # sometimes, there will be '<i> or <sup>, etc.' in the reference string; we need to remove it
                            self.npctDoc=ET.tostring(rfc.find('nplcit').find('othercit'))
                            self.npctDoc=re.sub('<[^>]+>','',self.npctDoc).rstrip('\n')
                            self.npctCategory=rfc.findtext('category')
                            self.sql_nonpatcit.append([self.pubNo,self.ctNum,self.__returnStr(self.npctDoc),self.__returnStr(self.npctCategory)])
                self.claimsNum=r.findtext('number-of-claims')
                for nof in r.findall('figures'):
                    self.drawingsNum=nof.findtext('number-of-drawing-sheets')
                    self.figuresNum=nof.findtext('number-of-figures')
                for prt in r.findall('parties'):
                    for apts in prt.findall('applicants'):
                        for apt in apts.findall('applicant'):
                            self.itSequence=apt.attrib['sequence']
                            if(apt.find('addressbook')!=None):
                                self.itFirstName=apt.find('addressbook').findtext('first-name')
                                self.itLastName=apt.find('addressbook').findtext('last-name')
                                self.itCity=apt.find('addressbook').find('address').findtext('city')
                                self.itState=apt.find('addressbook').find('address').findtext('state')
                                self.itCountry=apt.find('addressbook').find('address').findtext('country')
                                self.itNationality=apt.find('nationality').findtext('country')
                                self.itResidence=apt.find('residence').findtext('country')
                                self.sql_inventor.append([self.pubNo,self.itSequence,self.__returnStr(self.itFirstName),self.__returnStr(self.itLastName),self.__returnStr(self.itCity),self.__returnStr(self.itState),self.__returnStr(self.itCountry),self.__returnStr(self.itNationality),self.__returnStr(self.itResidence)])
                    for agns in prt.findall('agents'):
                        for agn in agns.findall('agent'):
                            self.asnSequence=agn.attrib['sequence']
                            if(agn.find('addressbook')!=None):
                                self.atnOrgName=agn.find('addressbook').findtext('orgname')
                                self.atnLastName=agn.find('addressbook').findtext('last-name')
                                self.atnFirstName=agn.find('addressbook').findtext('first-name')
                                self.atnCountry=agn.find('addressbook').find('address').findtext('country')
                                self.sql_agent.append([self.pubNo,self.asnSequence,self.__returnStr(self.atnOrgName),self.__returnStr(self.atnLastName),self.__returnStr(self.atnFirstName),self.__returnStr(self.atnCountry)])
                for asn in r.findall('assignees'):
                    self.position=1
                    for x in asn.findall('assignee'):
                        if(x.find('addressbook')!=None):
                            self.asnOrgName=x.find('addressbook').findtext('orgname')
                            self.asnRole=x.find('addressbook').findtext('role')
                            self.asnCity=x.find('addressbook').find('address').findtext('city')
                            self.asnState=x.find('addressbook').find('address').findtext('state')
                            self.asnCountry=x.find('addressbook').find('address').findtext('country')
                            self.sql_assignee.append([self.pubNo,self.position,self.__returnStr(self.asnOrgName),self.asnRole,self.__returnStr(self.asnCity),self.__returnStr(self.asnState),self.__returnStr(self.asnCountry)])
                            self.position+=1
                for exm in r.findall('examiners'):
                    for x in exm.findall('primary-examiner'):
                        self.exmLastName=x.findtext('last-name')
                        self.exmFirstName=x.findtext('first-name')
                        self.exmDepartment=x.findtext('department')
                        self.sql_examiner.append([self.pubNo,1,self.__returnStr(self.exmLastName),self.__returnStr(self.exmFirstName),self.__returnStr(self.exmDepartment)])
                    for x in exm.findall('assistant-examiner'):
                        self.exmLastName=x.findtext('last-name')
                        self.exmFirstName=x.findtext('first-name')
                        self.exmDepartment=x.findtext('department')
                        self.sql_examiner.append([self.pubNo,2,self.__returnStr(self.exmLastName),self.__returnStr(self.exmFirstName),self.__returnStr(self.exmDepartment)])
            #self.abstract=root.findtext('abstract')
            for abs in root.findall('abstract'):
                self.abstract=re.sub('<[^>]+>','',ET.tostring(abs)).strip()

        
            # ****** SQL Variables ********
            self.sql_application.append([self.__returnStr(self.appNo),self.__returnDate(self.appDate),self.appType])
            self.sql_publication.append([self.pubNo,self.__returnStr(self.title),self.__returnDate(self.pubDate),self.kind,self.seriesCode,self.__returnStr(self.abstract),self.__returnInt(self.claimsNum),self.__returnInt(self.drawingsNum),self.__returnInt(self.figuresNum),self.__returnStr(self.appNo),self.__returnStr(self.claims)])

        print '===== APPLICATION ====='
        print len(self.sql_application)
        print '===== PUBLICATION ====='
        print len(self.sql_publication)
        print '===== EXAMINER ====='
        print len(self.sql_examiner)
        print '===== ASSIGNEE ====='
        print len(self.sql_assignee)
        print '=====  AGENT ====='
        print len(self.sql_agent)
        print '===== INVENTOR ====='
        print len(self.sql_inventor)
        print '===== USCLASS ====='
        print len(self.sql_usclass)
        print '===== INTCLASS ====='
        print len(self.sql_intclass)
        print '===== PUBCIT ====='
        print len(self.sql_pubcit)
        print '===== GRACIT ====='
        print len(self.sql_gracit)
        print '===== FORPATCIT ====='
        print len(self.sql_forpatcit)
        print '===== NONPATCIT ====='
        print len(self.sql_nonpatcit)

        print '[Extracted .xml. Time:{0}]'.format(time.time()-btime)

    def __returnElementText(self,xmlElement):
        if(ET.iselement(xmlElement)):
            elementStr=ET.tostring(xmlElement)
            return re.sub('<[^<]*>','',elementStr).strip()
        else:return ''

    def extractXML1(self,xmlStr):      
        print '- Starting read .xml'
        self.__ResetSQLVariables()
        btime=time.time()
        patentRoot=ET.fromstring(xmlStr)
        #patentRoot=ET.ElementTree().parse('D:\PatentsData\PG_BD\haha.xml')
        print '[Finished read xml. Time:{0}]'.format(time.time()-btime)
        print '- Starting extract .xml'
        btime=time.time()
        # regular info.
        for root in patentRoot.findall('patent-application-publication'):
            self.__init__()
            for r in root.findall('subdoc-bibliographic-information'):
                for di in r.findall('document-id'):
                    self.pubCountry=''
                    self.pubNo=self.__returnElementText(di.find('doc-number'))
                    self.kind=self.__returnElementText(di.find('kind-code'))
                    self.pubDate=self.__returnElementText(di.find('document-date'))
                self.appType=self.__returnElementText(r.find('publication-filing-type'))
                for ar in r.findall('domestic-filing-data'):
                    self.appCountry=''
                    self.appNo=self.__returnElementText(ar.find('application-number'))
                    self.appDate=self.__returnElementText(ar.find('filing-date'))
                    self.seriesCode=self.__returnElementText(ar.find('application-number-series-code'))
                for cls in r.findall('technical-information'):
                    for ic in cls.findall('classification-ipc'):
                        self.position=1
                        for icm in ic.findall('classification-ipc-primary'):
                            self.iClassCls=self.__returnElementText(icm.find('ipc'))
                            self.sql_intclass.append([self.pubNo,self.position,self.iClassSec,self.iClassCls,self.iClassSub,self.iClassMgr,self.iClassSgr])
                            self.position+=1
                        for ics in ic.findall('classification-ipc-secondary'):
                            self.iClassCls=self.__returnElementText(ics)
                            self.sql_intclass.append([self.pubNo,self.position,self.iClassSec,self.iClassCls,self.iClassSub,self.iClassMgr,self.iClassSgr])
                            self.position+=1
                    for nc in cls.findall('classification-us'):
                        self.position=1
                        for ncp in nc.findall('classification-us-primary'):
                            for uspc in ncp.findall('uspc'):
                                self.nClassCountry=''
                                self.nClassInfo=''
                                self.nClassMain=self.__returnElementText(uspc.find('class'))
                                self.nSubclass=self.__returnElementText(uspc.find('subclass'))
                                self.sql_usclass.append([self.pubNo,self.position,self.__returnStr(self.nClassMain),self.__returnStr(self.nSubclass)])
                                self.position+=1
                        for ncs in nc.findall('classification-us-secondary'):
                            for uspc in ncs.findall('uspc'):
                                self.nClassMain=self.__returnElementText(uspc.find('class'))
                                self.nSubclass=self.__returnElementText(uspc.find('subclass'))
                                self.sql_usclass.append([self.pubNo,self.position,self.__returnStr(self.nClassMain),self.__returnStr(self.nSubclass)])
                                self.position+=1  
                    for ti in cls.findall('title-of-invention'):
                        self.title=self.__returnElementText(ti)
                for iv in r.findall('inventors'):
                    self.position=1
                    for fiv in iv.findall('first-named-inventor'):
                        for n in fiv.findall('name'):
                            self.itFirstName=self.__returnElementText(n.find('given-name'))
                            self.itLastName=self.__returnElementText(n.find('family-name'))
                        for re in fiv.findall('residence'):
                            if(re.find('residence-us')):
                                reu=re.find('residence-us')
                                self.itCity=self.__returnElementText(reu.find('city'))
                                self.itState=self.__returnElementText(reu.find('state'))
                                self.itCountry=self.__returnElementText(reu.find('country-code'))
                            elif(re.find('residence-non-us')):
                                reu=re.find('residence-non-us')
                                self.itCity=self.__returnElementText(reu.find('city'))
                                self.itState=self.__returnElementText(reu.find('state'))
                                self.itCountry=self.__returnElementText(reu.find('country-code'))
                        self.sql_inventor.append([self.pubNo,self.position,self.__returnStr(self.itFirstName),self.__returnStr(self.itLastName),self.__returnStr(self.itCity),self.__returnStr(self.itState),self.__returnStr(self.itCountry),self.__returnStr(self.itNationality),self.__returnStr(self.itResidence)])
                        self.position+=1
                    for ivs in iv.findall('inventor'):
                        for n in ivs.findall('name'):
                            self.itFirstName=self.__returnElementText(n.find('given-name'))
                            self.itLastName=self.__returnElementText(n.find('family-name'))
                        for re in ivs.findall('residence'):
                            if(re.find('residence-us')):
                                reu=re.find('residence-us')
                                self.itCity=self.__returnElementText(reu.find('city'))
                                self.itState=self.__returnElementText(reu.find('state'))
                                self.itCountry=self.__returnElementText(reu.find('country-code'))
                            elif(re.find('residence-non-us')):
                                reu=re.find('residence-non-us')
                                self.itCity=self.__returnElementText(reu.find('city'))
                                self.itState=self.__returnElementText(reu.find('state'))
                                self.itCountry=self.__returnElementText(reu.find('country-code'))
                        self.sql_inventor.append([self.pubNo,self.position,self.__returnStr(self.itFirstName),self.__returnStr(self.itLastName),self.__returnStr(self.itCity),self.__returnStr(self.itState),self.__returnStr(self.itCountry),self.__returnStr(self.itNationality),self.__returnStr(self.itResidence)])
                        self.position+=1
                for assn in r.findall('assignee'):
                    self.position=1
                    for on in assn.findall('organization-name'):
                        self.asnOrgName=self.__returnElementText(on)
                    for ad in assn.findall('address'):
                        self.asnCity=self.__returnElementText(ad.find('city'))
                        self.asnState=self.__returnElementText(ad.find('state'))
                    self.asnRole=self.__returnElementText(assn.find('assignee-type'))
                    self.sql_assignee.append([self.pubNo,self.position,self.__returnStr(self.asnOrgName),self.asnRole,self.__returnStr(self.asnCity),self.__returnStr(self.asnState),self.__returnStr(self.asnCountry)])
                    self.position+=1
                for agn in r.findall('correspondence-address'):
                    self.position=1
                    self.atnOrgName=self.__returnElementText(agn.find('name-1'))
                    for ads in agn.findall('address'):
                        self.atnLastName=''
                        self.atnFirstName=''
                        self.atnCountry=self.__returnElementText(ads.find('country'))
                    self.sql_agent.append([self.pubNo,self.position,self.__returnStr(self.atnOrgName),self.__returnStr(self.atnLastName),self.__returnStr(self.atnFirstName),self.__returnStr(self.atnCountry)])
                    self.position+=1
            for abs in root.findall('subdoc-abstract'):
                self.abstract=self.__returnElementText(abs)

        
            # ****** SQL Variables ********
            self.sql_application.append([self.__returnStr(self.appNo),self.__returnDate(self.appDate),self.appType])
            self.sql_publication.append([self.pubNo,self.__returnStr(self.title),self.__returnDate(self.pubDate),self.kind,self.seriesCode,self.__returnStr(self.abstract),self.__returnInt(self.claimsNum),self.__returnInt(self.drawingsNum),self.__returnInt(self.figuresNum),self.__returnStr(self.appNo),self.__returnStr(self.claims)])

        print '===== APPLICATION ====='
        print len(self.sql_application)
        print '===== PUBLICATION ====='
        print len(self.sql_publication)
        print '===== EXAMINER ====='
        print len(self.sql_examiner)
        print '===== ASSIGNEE ====='
        print len(self.sql_assignee)
        print '=====  AGENT ====='
        print len(self.sql_agent)
        print '===== INVENTOR ====='
        print len(self.sql_inventor)
        print '===== USCLASS ====='
        print len(self.sql_usclass)
        print '===== INTCLASS ====='
        print len(self.sql_intclass)
        print '===== PUBCIT ====='
        print len(self.sql_pubcit)
        print '===== GRACIT ====='
        print len(self.sql_gracit)
        print '===== FORPATCIT ====='
        print len(self.sql_forpatcit)
        print '===== NONPATCIT ====='
        print len(self.sql_nonpatcit)

        print '[Extracted .xml. Time:{0}]'.format(time.time()-btime)

    def writeCSV(self,fileName):
        print '- Starting write .csv'
        fileName=fileName+'.csv'
        import csv
        st=time.time()
        self.f_application=open(self.csvPath_application+fileName,'wt')
        self.f_publication=open(self.csvPath_publication+fileName,'wt')
        self.f_examiner=open(self.csvPath_examiner+fileName,'wt')
        self.f_agent=open(self.csvPath_agent+fileName,'wt')
        self.f_assignee=open(self.csvPath_assignee+fileName,'wt')
        self.f_inventor=open(self.csvPath_inventor+fileName,'wt')
        self.f_pubcit=open(self.csvPath_pubcit+fileName,'wt')
        self.f_gracit=open(self.csvPath_gracit+fileName,'wt')
        self.f_forpatcit=open(self.csvPath_forpatcit+fileName,'wt')
        self.f_nonpatcit=open(self.csvPath_nonpatcit+fileName,'wt')
        self.f_usclass=open(self.csvPath_usclass+fileName,'wt')
        self.f_intclass=open(self.csvPath_intclass+fileName,'wt')
        w_application=csv.writer(self.f_application,delimiter='\t',lineterminator='\n')
        w_application.writerows(self.sql_application)
        w_publication=csv.writer(self.f_publication,delimiter='\t',lineterminator='\n')
        w_publication.writerows(self.sql_publication)
        w_examiner=csv.writer(self.f_examiner,delimiter='\t',lineterminator='\n')
        w_examiner.writerows(self.sql_examiner)
        w_agent=csv.writer(self.f_agent,delimiter='\t',lineterminator='\n')
        w_agent.writerows(self.sql_agent)
        w_assignee=csv.writer(self.f_assignee,delimiter='\t',lineterminator='\n')
        w_assignee.writerows(self.sql_assignee)
        w_inventor=csv.writer(self.f_inventor,delimiter='\t',lineterminator='\n')
        w_inventor.writerows(self.sql_inventor)
        w_pubcit=csv.writer(self.f_pubcit,delimiter='\t',lineterminator='\n')
        w_pubcit.writerows(self.sql_pubcit)
        w_gracit=csv.writer(self.f_gracit,delimiter='\t',lineterminator='\n')
        w_gracit.writerows(self.sql_gracit)
        w_forpatcit=csv.writer(self.f_forpatcit,delimiter='\t',lineterminator='\n')
        w_forpatcit.writerows(self.sql_forpatcit)
        w_nonpatcit=csv.writer(self.f_nonpatcit,delimiter='\t',lineterminator='\n')
        w_nonpatcit.writerows(self.sql_nonpatcit)
        w_usclass=csv.writer(self.f_usclass,delimiter='\t',lineterminator='\n')
        w_usclass.writerows(self.sql_usclass)
        w_intclass=csv.writer(self.f_intclass,delimiter='\t',lineterminator='\n')
        w_intclass.writerows(self.sql_intclass)
        self.f_application.close()
        self.f_publication.close()
        self.f_examiner.close()
        self.f_agent.close()
        self.f_assignee.close()
        self.f_inventor.close()
        self.f_pubcit.close()
        self.f_gracit.close()
        self.f_forpatcit.close()
        self.f_nonpatcit.close()
        self.f_usclass.close()
        self.f_intclass.close()
        print '[CSV files has been written successfully. Cost time:{0}]'.format(time.time()-st)
        print 'Getting started to load .csv file into the database...'
        st=time.time()
        self.processor=MySQLProcessor.MySQLProcess()
        self.processor.connect()

        print '***** APPLICATION *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.APPLICATION        FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n'
        (ApplicationID,FileDate,AppType);
        """.format(filePath=self.csvPath_application.replace('\\','/')+fileName))

        print '***** PUBLICATION *****'
        print self.processor.load("""SET foreign_key_checks = 0;""")
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.PUBLICATION        FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_publication.replace('\\','/')+fileName))

        print '***** EXAMINER *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.EXAMINER_P        FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_examiner.replace('\\','/')+fileName))

        print '***** AGENT *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.AGENT_P      FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_agent.replace('\\','/')+fileName))

        print '***** ASSIGNEE *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.ASSIGNEE_P      FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_assignee.replace('\\','/')+fileName))

        print '***** INVENTOR *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.INVENTOR_P      FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_inventor.replace('\\','/')+fileName))

        print '***** PUBCIT *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.PUBCIT_P      FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_pubcit.replace('\\','/')+fileName))

        print '***** GRACIT *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.GRACIT_P      FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_gracit.replace('\\','/')+fileName))

        print '***** FORPATCIT *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.FORPATCIT_P      FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_forpatcit.replace('\\','/')+fileName))

        print '***** NONPATCIT *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.NONPATCIT_P      FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_nonpatcit.replace('\\','/')+fileName))

        print '***** USCLASS *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.USCLASS_P      FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_usclass.replace('\\','/')+fileName))

        print '***** INTCLASS *****'
        print self.processor.load("""LOAD DATA LOCAL INFILE '{filePath}'
        IGNORE INTO TABLE qliu14.INTCLASS_P      FIELDS TERMINATED BY '\\t'        OPTIONALLY ENCLOSED BY '\"'        LINES TERMINATED BY '\\n';
        """.format(filePath=self.csvPath_intclass.replace('\\','/')+fileName))

        print self.processor.load("""SET foreign_key_checks = 1;""")
        self.processor.close()
        self.__ResetSQLVariables()
        print '[Loaded .csv. Time:{0}]'.format(time.time()-st)

# main function for multiprocessing
def mainProcess(linkList,formatStr):
    print '- Process {0} is starting to work!'.format(os.getpid())
    pst=time.time()
    for link in linkList:
        st=time.time()
        fileName=os.path.basename(link)
        log=LogProcessor.LogProcess()
        if(formatStr=='xml4'):
            try:
                sp=SourceParser.SourceParser()
                xmlStr=sp.getXML4Content(link,sp.fileDir_PG_BD)
                os.remove(sp.filePath)
                p=PublicationsParser()
                p.extractXML4(xmlStr)
                p.writeCSV(fileName)
                log.write(log.logPath_P,fileName+'\t'+link+'\t'+formatStr+'\t'+'Processed')
            except:
                log.write(log.logPath_P,fileName+'\t'+link+'\t'+formatStr+'\t'+'Failed')
                continue
        elif(formatStr=='xml1'):
            try:
                sp=SourceParser.SourceParser()
                xmlStr=sp.getXML1Content(link,sp.fileDir_PG_BD)
                os.remove(sp.filePath)
                p=PublicationsParser()
                p.extractXML1(xmlStr)
                p.writeCSV(fileName)
                log.write(log.logPath_P,fileName+'\t'+link+'\t'+formatStr+'\t'+'Processed')
            except:
                log.write(log.logPath_P,fileName+'\t'+link+'\t'+formatStr+'\t'+'Failed')
                continue
        print '[Finishing processing one .zip package! Time consuming:{0}]'.format(time.time()-st)
    print '[Process {0} is finished. Cost Time:{1}]'.format(os.getpid(),time.time()-pst)

if __name__=="__main__":
    st=time.time()
    sp=SourceParser.SourceParser()
    sp.getALLFormats()
    ls_xml4=sp.links_P_XML4 #396
    ls_xml1=sp.links_P_XML1 #199
    processes=[]
    #595 links, 4 processes
    ls_xml1_p=[ls_xml1[0:50],ls_xml1[50:100],ls_xml1[100:150],ls_xml1[150:len(ls_xml1)]]
    for linkList in ls_xml1_p:
        processes.append(multiprocessing.Process(target=mainProcess,args=(linkList,'xml1')))
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    print '[Finished all xml1 files]'

    processes=[]
    ls_xml4_p=[ls_xml4[0:100],ls_xml4[100:200],ls_xml4[200:300],ls_xml4[300:len(ls_xml4)]]
    for linkList in ls_xml4_p:
        processes.append(multiprocessing.Process(target=mainProcess,args=(linkList,'xml4')))
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    print '[Finished all xml4 files]'
    print ('Congratulations! All Publications Cost time:{0} \nPress ENTER to continue. '.format(time.time()-st))
