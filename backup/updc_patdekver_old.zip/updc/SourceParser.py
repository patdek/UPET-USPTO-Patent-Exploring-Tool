import urllib
from HTMLParser import HTMLParser
import re
import os
import time
import zipfile
import LogProcessor

class SourceParser:
    """
    Used to access the webpage and extract all the downloadable URLs to download Google Patent .zip files AND extract the XML file.
    1. get all the downloadable links of patents
    2. get preprocessed contents of .zip files
    3. return contents to data parsers
    """
    def __init__(self):
        # Patent Grants Variables
        self.urlSource_PG_BD='http://www.google.com/googlebooks/uspto-patents-grants-biblio.html'
        self.urlPattern_PG_BD='(http://storage.googleapis.com/patents/grantbib).*(\.zip)'
        self.dLinks_PG_BD=[] # downloadable links (.zip files address)
        self.fileDir_PG_BD=os.getcwd().replace('\\','/')+"/PG_BD"  #'d:/PatentsData/PG_BD'
        self.links_G_XML4=[]
        self.links_G_XML2=[]
        self.links_G_XML2_4=[]
        self.links_G_APS=[]

        # Patent Application Publications Variables
        self.urlSource_PP_BD='http://www.google.com/googlebooks/uspto-patents-applications-biblio.html'
        self.urlPattern_PP_BD='(http://storage.googleapis.com/patents/appl_bib).*(\.zip)'
        self.dLinks_PP_BD=[] # downloadable links (.zip files address)
        self.fileDir_PP_BD=os.getcwd().replace('\\','/')+"/PP_BD"  #'d:/PatentsData/PA_BD'
        self.links_P_XML4=[]
        self.links_P_XML1=[]

        # Patent Application Information Retrieval
        self.urlLinkName_PAIR='http://commondatastorage.googleapis.com/uspto-pair/applications/[replaceNum].zip'
        self.urlSource_PAIR=os.getcwd().replace('\\','/')+"/ID/PAIRLinks"
        self.fileDir_PAIR=os.getcwd().replace('\\','/')+'/PAIR'
        self.dLinks_PAIR=[]

        # Public Variables
        self.fileName=''
        self.fileDir=''
        self.filePath=''
        self.filePathXML=''
        self.xmlStr=''
        self.links=[] # links in the Webpage

    def getWebContent(self,url='http://www.google.com'):
        return urllib.urlopen(url).read()

    def matchDownload(self,urlPattern='.*(\.zip)',link=''):
        result=re.match(urlPattern,link)
        try:
            return result.string
        except: #return NoneType
            return None

    def returnMatch(self,pattern,string):
        c=re.compile(pattern)
        m=c.match(string)
        return m

    def returnRegLine(self,line):
        """
        USED FOR REPLACE ERROR CODE FOR HTML 
        HTML escape characters
        """
        c=re.compile('&[a-z|A-Z|0-9]*;')
        ls=c.findall(line)
        for l in ls:
            if(l=='&amp;'):line=line.replace(l,'&#x26;') #'&#38;')
            elif(l=='&lt;'):line=line.replace(l,'&#x3C;') #'&#60;')
            elif(l=='&gt;'):line=line.replace(l,'&#x3E;') #&#62;')
            elif(l=='&quot;'):line=line.replace(l,'&#x22;') #&#34;')
            elif(l=='&lsquo;'):line=line.replace(l,'&#x2018;') #&#8216;')
            elif(l=='&rsquo;'):line=line.replace(l,'&#x2019;') #&#8217;')
            elif(l=='&ldquo;'):line=line.replace(l,'&#x201C;') #&#8220;')
            elif(l=='&rdquo;'):line=line.replace(l,'&#x201D;') #&#8221;')
            elif(l=='&sbquo;'):line=line.replace(l,'&#x201A;') #&#8218;')
            elif(l=='&bdquo;'):line=line.replace(l,'&#x201E;') #&#8222;')
            elif(l=='&ndash;'):line=line.replace(l,'&#x2013;') #&#8211;')
            elif(l=='&mdash;'):line=line.replace(l,'&#x2014;') #&#8212;')
            #elif(l=='&minus;'):line=line.replace(l,'&#8722;')
            #elif(l=='&times;'):line=line.replace(l,'&#215;')
            #elif(l=='&divide;'):line=line.replace(l,'&#247;')
            #elif(l=='&copy;'):line=line.replace(l,'&#169;')
            elif(l=='&lsaquo;'):line=line.replace(l,'&#x2039;')
            elif(l=='&rsaquo;'):line=line.replace(l,'&#x203A;')
            else:
                line=re.sub('&[a-z|A-Z|0-9]*;','|',line)
        return line

    def getdLinksPG(self):
        """
        Used to get all downloadable links of Patent Grants
        """
        content=self.getWebContent(self.urlSource_PG_BD)
        htmlP=LinksParser()
        self.links=htmlP.read(content)
        for i in self.links:
            if(self.matchDownload(self.urlPattern_PG_BD,i)!=None):
                self.dLinks_PG_BD.append(i)
        print '[get patent grants downloadable links successfully! Num:{0}]'.format(len(self.dLinks_PG_BD))
        return self.dLinks_PG_BD

    def getdLinksPP(self):
        """
        Used to get all downloadable links of Patent Application Publications
        """
        content=self.getWebContent(self.urlSource_PP_BD)
        htmlP=LinksParser()
        self.links=htmlP.read(content)
        for i in self.links:
            if(self.matchDownload(self.urlPattern_PP_BD,i)!=None):
                self.dLinks_PP_BD.append(i)
        print '[get patent applications downloadable links successfully! Num:{0}]'.format(len(self.dLinks_PP_BD))
        return self.dLinks_PP_BD

    def getdLinksPAIR(self):
        """
        Used to get all downloadable links of Patent Application Information Retrieval data
        """
        reader=open(self.urlSource_PAIR,'rb')
        strLines=reader.readlines()
        for s in strLines:
            ls_str=s.replace('-','').split()
            ls_num=[]
            for num in range(int(ls_str[0]),int(ls_str[1])+1):
                ls_num.append(num)
            for num in ls_num:
                strZero=''
                if(num<10000000):
                    for i in range(0,8-len(str(num))):
                        strZero+='0'
                    self.dLinks_PAIR.append(self.urlLinkName_PAIR.replace('[replaceNum]',strZero+str(num)))
                else:
                    self.dLinks_PAIR.append(self.urlLinkName_PAIR.replace('[replaceNum]',str(num)))
        print '[get PAIR data downloadable links successfully! Num:{0}]'.format(len(self.dLinks_PAIR))
        return self.dLinks_PAIR

    def getALLFormats(self):
        """
        get all the formats of grants and publications
        return list
        """
        gXML4='ipgb.*.zip'
        gXML2='pgb.*.zip'
        gXML2_4='pgb2001.*.zip'
        gAPS='[0-9]{4}.zip|pba.*.zip'
        pXML4='ipab.*.zip'
        pXML1='pab.*.zip'
        linkList_G=self.getdLinksPG()
        for link in linkList_G:
            fileName=os.path.basename(link)
            if(self.returnMatch(gXML4,fileName)):
                self.links_G_XML4.append(link)
            elif(self.returnMatch(gXML2,fileName)):
                if(self.returnMatch(gXML2_4,fileName)):
                    self.links_G_XML2_4.append(link)
                else:
                    self.links_G_XML2.append(link)
            elif(self.returnMatch(gAPS,fileName)):
                self.links_G_APS.append(link)
            else:
                raw_input('ERROR ENTER')
        print 'gXML4:{0}\ngXML2:{1}\ngXML2_4:{2}\nAPS:{3}'.format(len(self.links_G_XML4),len(self.links_G_XML2),len(self.links_G_XML2_4),len(self.links_G_APS))
        linkList_P=self.getdLinksPP()
        for link in linkList_P:
            fileName=os.path.basename(link)
            if(self.returnMatch(pXML4,fileName)):
                self.links_P_XML4.append(link)
            elif(self.returnMatch(pXML1,fileName)): 
                self.links_P_XML1.append(link)
            else:
                raw_input('ERROR ENTER')
        print 'pXML4:{0}\npXML1:{1}'.format(len(self.links_P_XML4),len(self.links_P_XML1))


    def getXML4Content(self,dLink='',fileDir=''):
        """
        USED FOR GRANT & PUBLICATION FORMAT: XML4 and upper
        1. download .zip file
        2. generate well-formed .xml file
        3. read .xml file and then return a string to be used by ElementTree
        """
        sTime=time.time()
        self.fileDir=fileDir
        self.fileName=os.path.basename(dLink)
        self.filePath=self.fileDir+'/'+self.fileName
        self.filePathXML=self.filePath+'.xml'
        urllib.urlretrieve(dLink,self.filePath)
        urllib.urlcleanup()
        print '[Downloaded .zip file: {0} Time:{1}]'.format(self.fileName,time.time()-sTime)

        sTime=time.time()
        print '- Starting generate well-formed xml4.'
        import zipfile
        myzip=zipfile.ZipFile(self.filePath,'r')
        fileNameList=myzip.namelist()
        zipfile=myzip.open(fileNameList[0],'r')
        xmlList=[]
        xmlList.insert(0,'<PatentRoot>\r\n')
        for line in zipfile:
            if(line[0:len('<?xml')]!='<?xml' and (line[0:len('<!DOCTYPE')]!='<!DOCTYPE') and (line[0:len('<!ENTITY')]!='<!ENTITY') and (line[0:len(']>')]!=']>')):
                xmlList.append(line)
        myzip.close()
        xmlList.insert(len(xmlList),'</PatentRoot>')
        self.xmlStr=''.join(xmlList)
        #os.remove(self.filePath)
        #xmlFile=open(self.filePath+'.xml','wb') #the most efficient way in comparison with open(path,'w')
        #xmlFile.write(self.xmlStr) #the most efficient way in comparison with writelines(list)
        #xmlFile.close()
        print '[Generated well-formed xml. Time:{0}]'.format(time.time()-sTime)
        return self.xmlStr

    def getXML2Content(self,dLink='',fileDir=''):
        """
        USED FOR GRANT FORMAT: XML2 and upper
        1. download .zip file
        2. generate well-formed .xml file
        3. read .xml file and then return a string to be used by ElementTree
        """
        sTime=time.time()
        self.fileDir=fileDir
        self.fileName=os.path.basename(dLink)
        self.filePath=self.fileDir+'/'+self.fileName
        self.filePathXML=self.filePath+'.xml'
        urllib.urlretrieve(dLink,self.filePath)
        urllib.urlcleanup()
        print '[Downloaded .zip file: {0} Time:{1}]'.format(self.fileName,time.time()-sTime)
        sTime=time.time()
        print '- Starting generating well-formed xml2.'
        import zipfile
        myzip=zipfile.ZipFile(self.filePath,'r')
        for name in myzip.namelist():
            if(name.find('.xml')>-1 or name.find('.sgml')>-1):
                xmlFileName=name
        zipfile=myzip.open(xmlFileName,'r')
        xmlList=[]
        xmlList.insert(0,'<PatentRoot>\r\n')
        for line in zipfile:
            if(line[0:len('<?xml')]!='<?xml' and (line[0:len('<!DOCTYPE')]!='<!DOCTYPE') and (line[0:len('<!ENTITY')]!='<!ENTITY') and (line[0:len(']>')]!=']>')):
                xmlList.append(self.returnRegLine(line))
        myzip.close()
        xmlList.insert(len(xmlList),'</PatentRoot>')
        self.xmlStr=''.join(xmlList)
        #os.remove(self.filePath)
        #xmlFile=open(self.filePath+'.xml','wb') #the most efficient way in comparison with open(path,'w')
        #xmlFile.write(self.xmlStr) #the most efficient way in comparison with writelines(list)
        #xmlFile.close()
        print '[Generated well-formed xml. Time:{0}]'.format(time.time()-sTime)
        return self.xmlStr

    def getXML1Content(self,dLink='',fileDir=''):
        """
        USED FOR PUBLICAITON FORMAT: XML1.0 and upper
        1. download .zip file
        2. generate well-formed .xml file
        3. read .xml file and then return a string to be used by ElementTree
        """
        sTime=time.time()
        self.fileDir=fileDir
        self.fileName=os.path.basename(dLink)
        self.filePath=self.fileDir+'/'+self.fileName
        self.filePathXML=self.filePath+'.xml'
        urllib.urlretrieve(dLink,self.filePath)
        urllib.urlcleanup()
        print '[Downloaded .zip file: {0} Time:{1}]'.format(self.fileName,time.time()-sTime)
        sTime=time.time()
        print '- Starting generating well-formed xml1.'
        import zipfile
        myzip=zipfile.ZipFile(self.filePath,'r')
        for name in myzip.namelist():
            if(name.find('.xml')>-1 or name.find('.sgml')>-1):
                xmlFileName=name
        zipfile=myzip.open(xmlFileName,'r')
        xmlList=[]
        xmlList.insert(0,'<PatentRoot>\r\n')
        for line in zipfile:
            if(line[0:len('<?xml')]!='<?xml' and (line[0:len('<!DOCTYPE')]!='<!DOCTYPE') and (line[0:len('<!ENTITY')]!='<!ENTITY') and (line[0:len(']>')]!=']>')):
                xmlList.append(self.returnRegLine(line))
        myzip.close()
        xmlList.insert(len(xmlList),'</PatentRoot>')
        self.xmlStr=''.join(xmlList)
        #xmlFile=open(self.filePath+'.xml','wb') #the most efficient way in comparison with open(path,'w')
        #xmlFile.write(self.xmlStr) #the most efficient way in comparison with writelines(list)
        #xmlFile.close()
        print '[Generated well-formed xml. Time:{0}]'.format(time.time()-sTime)
        return self.xmlStr

    def getAPSContent(self,dLink='',fileDir=''):
        """
        USED FOR GRANTS FORMAT: APS
        1.download the .zip file
        2.transform the .dat/.txt file into a new preprocessed string list
        3.return the string list (save space to be processed in the memory)
        """
        st=time.time()
        self.fileDir=fileDir
        self.fileName=os.path.basename(dLink)
        self.filePath=self.fileDir+'/'+self.fileName
        urllib.urlretrieve(dLink,self.filePath)
        urllib.urlcleanup()
        print '[Downloaded .zip file: {0} Time:{1}]'.format(self.fileName,time.time()-st)
        st=time.time()
        print '- Starting process APS(.dat or .txt)'
        myzip=zipfile.ZipFile(self.filePath,'r')
        for name in myzip.namelist():
            if(self.returnMatch('.*.dat',name)!=None or self.returnMatch('[a-z]*[0-9]*.txt',name)!=None):
                self.datFileName=name
        datReader=myzip.open(self.datFileName,'r')
        datList=[]
        header=''
        for line in datReader:
            if(len(line.strip())==4):
                datList.append('END|'+header)
                header=line.strip()
                if(header=='PATN'):datList.append('END|***')
            if(len(line[0:4].strip())==0): #append newline
                datList[len(datList)-1]+=' '+line.strip()
            else:datList.append(header+'|'+line.strip())
        datList.append('END|***')
        #datFile=open(self.filePath+'.dat','wb') #the most efficient way in comparison with open(path,'w')
        #datStr='\n'.join(datList)
        #datFile.write(datStr)
        #datFile.close()
        print '[Processed APS(.bat or .txt) File. Length:{0} Time: {1}]'.format(len(datList),time.time()-st)
        #os.remove(self.filePath)
        return datList


# parse HTML file to get links <a>
class LinksParser(HTMLParser): 
    def __init__(self):
        HTMLParser.__init__(self)

    def read(self,data):
        self._lines=[]
        self.reset()
        self.feed(data)
        return self._lines

    def handle_starttag(self, tag, attrs):   
        if tag == 'a':
            for name,value in attrs:
                if name == 'href':
                    self._lines.append(str(value))
